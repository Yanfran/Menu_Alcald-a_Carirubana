<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<style>
		img{
			display: block;
 			margin: 0px auto;;
			background-size: cover;
		}
	</style>
</head>
<body>
	<img src="mantenimiento.jpeg" alt="">
</body>
</html>